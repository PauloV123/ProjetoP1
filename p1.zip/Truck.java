import java.util.Iterator;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.Random;

public class Truck extends Vehicles{
	private int carga;
	
	public Truck(int x, int y,int velo, boolean fabrica){
		super(x,y,1,false);
	}

}
