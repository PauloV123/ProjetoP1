import java.util.Iterator;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.Random;

public class Car extends Vehicles{
	private int Pass;
	
	public Car(int x, int y,int velo, boolean fabrica){
		super(x,y,2,false);
	}

}
