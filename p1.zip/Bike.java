
import java.util.Iterator;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.Random;

public class Bike extends Vehicles{
	private String Placa;
	
	public Bike(int x, int y,int velo, boolean fabrica){
		super(x,y,3,false);
	}

}